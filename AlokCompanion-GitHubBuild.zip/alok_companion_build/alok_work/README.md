# Alok Companion for Gboard

Gboard remains the user's selected keyboard. Alok Companion is a separate helper app for applying five text transformations and copying the result to the clipboard for pasting into any app with Gboard.

## Included transformations
- MONO
- BANANA
- ALTERNATE
- REVERSE
- CHIPKU

## Important limitation
Android does not provide third-party apps a supported way to add custom buttons to Gboard's private keyboard UI. This app uses a clipboard workflow; it does not modify Gboard itself.

## Build without Android Studio (GitHub Actions)
1. Create a new empty GitHub repository.
2. Upload the **contents of this `alok_work` folder** to the repository root (not the outer folder itself).
3. Open the repository's **Actions** tab.
4. Select **Build Alok Companion APK** and tap **Run workflow** (or wait for the automatic build after uploading to `main`).
5. When the run finishes, open it and download the `AlokCompanion-debug-apk` artifact.
6. Extract the downloaded artifact ZIP on your Android phone and install `app-debug.apk`.

The workflow uses Java 17 and Gradle 8.7; no Android IDE is required on your phone.
