package com.alok.keyboard.ime

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView
import com.alok.keyboard.R
import com.alok.keyboard.transform.TextTransformer
import com.alok.keyboard.transform.TransformType

class AlokInputMethodService : InputMethodService(), AlokKeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: AlokKeyboardView

    private lateinit var btnMono: LinearLayout
    private lateinit var btnBanana: LinearLayout
    private lateinit var btnAlternate: LinearLayout
    private lateinit var btnReverse: LinearLayout
    private lateinit var btnChipku: LinearLayout

    private lateinit var previewMono: TextView
    private lateinit var previewBanana: TextView
    private lateinit var previewAlternate: TextView
    private lateinit var previewReverse: TextView
    private lateinit var previewChipku: TextView

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.keyboard_container, null)

        keyboardView = root.findViewById(R.id.alok_keyboard_view)
        keyboardView.listener = this

        btnMono = root.findViewById(R.id.btn_transform_mono)
        btnBanana = root.findViewById(R.id.btn_transform_banana)
        btnAlternate = root.findViewById(R.id.btn_transform_alternate)
        btnReverse = root.findViewById(R.id.btn_transform_reverse)
        btnChipku = root.findViewById(R.id.btn_transform_chipku)

        previewMono = root.findViewById(R.id.preview_mono)
        previewBanana = root.findViewById(R.id.preview_banana)
        previewAlternate = root.findViewById(R.id.preview_alternate)
        previewReverse = root.findViewById(R.id.preview_reverse)
        previewChipku = root.findViewById(R.id.preview_chipku)

        btnMono.setOnClickListener { applyTransformation(TransformType.MONO) }
        btnBanana.setOnClickListener { applyTransformation(TransformType.BANANA) }
        btnAlternate.setOnClickListener { applyTransformation(TransformType.ALTERNATE) }
        btnReverse.setOnClickListener { applyTransformation(TransformType.REVERSE) }
        btnChipku.setOnClickListener { applyTransformation(TransformType.CHIPKU) }

        updateLivePreviews()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        updateLivePreviews()
    }

    override fun onUpdateSelection(
        oldSelStart: Int,
        oldSelEnd: Int,
        newSelStart: Int,
        newSelEnd: Int,
        candidatesStart: Int,
        candidatesEnd: Int
    ) {
        super.onUpdateSelection(
            oldSelStart,
            oldSelEnd,
            newSelStart,
            newSelEnd,
            candidatesStart,
            candidatesEnd
        )
        updateLivePreviews()
    }

    /**
     * Reads the currently typed word before the cursor without altering editor state.
     */
    private fun getCurrentTypedWord(): String {
        val ic: InputConnection = currentInputConnection ?: return ""
        val before = ic.getTextBeforeCursor(64, 0) ?: return ""
        return TextTransformer.extractCurrentWordBeforeCursor(before)
    }

    /**
     * Updates the live transformation previews inside all 5 buttons instantly as the user types.
     */
    private fun updateLivePreviews() {
        if (!::previewMono.isInitialized) return

        val currentWord = getCurrentTypedWord()
        val sample = currentWord.ifEmpty { "alok" }

        previewMono.text = TextTransformer.transform(sample, TransformType.MONO)
        previewBanana.text = TextTransformer.transform(sample, TransformType.BANANA)
        previewAlternate.text = TextTransformer.transform(sample, TransformType.ALTERNATE)
        previewReverse.text = TextTransformer.transform(sample, TransformType.REVERSE)
        previewChipku.text = TextTransformer.transform(sample, TransformType.CHIPKU)

        val alpha = if (currentWord.isNotEmpty()) 1.0f else 0.72f
        btnMono.alpha = alpha
        btnBanana.alpha = alpha
        btnAlternate.alpha = alpha
        btnReverse.alpha = alpha
        btnChipku.alpha = alpha
    }

    /**
     * Atomically replaces the currently typed word before the cursor with the transformed text,
     * keeping cursor position at the exact end of the replaced word without duplicate characters
     * or accidental trailing spaces.
     */
    private fun applyTransformation(type: TransformType) {
        val ic: InputConnection = currentInputConnection ?: return
        val currentWord = getCurrentTypedWord()
        if (currentWord.isEmpty()) return

        val transformed = TextTransformer.transform(currentWord, type)
        if (transformed == currentWord) return

        performHapticFeedback()

        ic.beginBatchEdit()
        try {
            // If user has selected text, clear selection first cleanly
            val selected = ic.getSelectedText(0)
            if (!selected.isNullOrEmpty()) {
                ic.commitText("", 1)
            }
            // Delete exact length of current word before cursor and commit replacement
            ic.deleteSurroundingText(currentWord.length, 0)
            ic.commitText(transformed, 1)
        } finally {
            ic.endBatchEdit()
        }

        updateLivePreviews()
    }

    override fun onCharacterKey(text: String) {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        ic.commitText(text, 1)
        updateLivePreviews()
    }

    override fun onBackspace() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        val selectedText = ic.getSelectedText(0)
        if (!selectedText.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
        updateLivePreviews()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        ic.commitText(" ", 1)
        updateLivePreviews()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        performHapticFeedback()
        val editorInfo = currentInputEditorInfo
        val action = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE

        if (action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED &&
            (editorInfo.inputType and EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE) == 0
        ) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateLivePreviews()
    }

    override fun onShiftToggle() {
        performHapticFeedback()
    }

    override fun onSwitchSymbols() {
        performHapticFeedback()
    }

    override fun onSwitchEmoji() {
        performHapticFeedback()
    }

    override fun onSwitchLanguage() {
        performHapticFeedback()
        updateLivePreviews()
    }

    private fun performHapticFeedback() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val mgr = getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                mgr?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
            // Safe fallback on devices without vibrator permission/hardware
        }
    }
}
